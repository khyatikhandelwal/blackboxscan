# BlackBoxScan
<div align="center">
  <img width="228" alt="blackboxscan" src="https://github.com/user-attachments/assets/2cb1b82c-137b-414f-be74-8b84ca4cf100">
</div>



This Python library can be used to easily measure, visualise and probe the HuggingFace LLMs.
